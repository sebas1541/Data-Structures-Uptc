package co.edu.uptc.structures;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Addition {
    private String numbers;

    public Addition(String numbers) {
        this.numbers = numbers;
    }
    public Addition(){

    }

    public String add() {

        String[] nums = this.numbers.split("\\s+");
        MyQueue<Integer> result = new MyQueue<>();

        for (String num : nums) {
            MyStack<Integer> stack = new MyStack<>();
            for (char c : num.toCharArray()) {
                stack.push(Character.getNumericValue(c));
            }

            MyQueue<Integer> newResult = new MyQueue<>();
            int countNext = 0;

            while (!stack.isEmpty() || !result.isEmpty() || countNext != 0) {
                int sum = countNext;

                if (!stack.isEmpty()) {
                    sum += stack.pop();
                }
                if (!result.isEmpty()) {
                    sum += result.poll();
                }

                newResult.push(sum % 10);
                countNext = sum / 10;
            }
            result = newResult;
        }
        StringBuilder finalResult = new StringBuilder();
        while (!result.isEmpty()) {
            finalResult.insert(0, result.poll());
        }
        return finalResult.toString();
    }

    public String readFile(String filename){

        String numbers = "";
        try {
            File file = new File(filename);

            Scanner myReader = new Scanner(file);
            while (myReader.hasNextLine()) {
                numbers =  myReader.nextLine();
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return numbers;
    }


    public String getNumbers() {
        return numbers;
    }
    public void setNumbers(String numbers) {
        this.numbers = numbers;
    }
}