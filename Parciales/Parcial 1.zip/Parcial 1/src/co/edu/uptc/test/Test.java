package co.edu.uptc.test;


import co.edu.uptc.structures.Addition;

public class Test {
    public static void main(String[] args) {
        Addition addition1 = new Addition("12123123 14321534122 11235124562342 1213452345234");


        System.out.println(addition1.add());


    }
}
