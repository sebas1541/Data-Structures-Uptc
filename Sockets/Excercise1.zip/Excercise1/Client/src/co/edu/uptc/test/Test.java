package co.edu.uptc.test;

import co.edu.uptc.presenter.ClientPresenter;

public class Test {
    public static void main(String[] args) {
        new ClientPresenter();
    }
}
