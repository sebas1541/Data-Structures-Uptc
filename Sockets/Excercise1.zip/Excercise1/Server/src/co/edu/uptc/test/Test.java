package co.edu.uptc.test;

import co.edu.uptc.presenter.ServerPresenter;

import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        new ServerPresenter();
    }
}
